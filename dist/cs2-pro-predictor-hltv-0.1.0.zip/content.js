// CS2 Pro Predictor (HLTV) — фаза 1: статистика вето и винрейтов, без модели.
// Читает уже отрендеренную страницу матча; запросов к HLTV не делает.
(() => {
  if (window.__hltvProLoaded) return;
  window.__hltvProLoaded = true;

  const MIN_GAMES = 5;    // меньше — не сравниваем
  const THIN_GAMES = 10;  // меньше — предупреждаем о тонкой выборке
  const NOISE_PP = 8;     // разрыв меньше — шум
  const MAP_CODES = {
    ancient: 'de_ancient', dust2: 'de_dust2', dust64: 'de_dust2', inferno: 'de_inferno',
    mirage: 'de_mirage', nuke: 'de_nuke', anubis: 'de_anubis', cache: 'de_cache',
    overpass: 'de_overpass', train: 'de_train', vertigo: 'de_vertigo',
  };

  const txt = (n) => (n && n.textContent ? n.textContent.trim() : '');
  const pctVal = (s) => {
    const m = /(\d+(?:[.,]\d+)?)\s*%/.exec(s || '');
    return m ? parseFloat(m[1].replace(',', '.')) : null;
  };
  const intVal = (s) => {
    const m = /(\d+)/.exec(s || '');
    return m ? parseInt(m[1], 10) : null;
  };
  const mapKey = (name) => MAP_CODES[String(name || '').toLowerCase().replace(/[^a-z0-9]/g, '')] || null;
  const mapLabel = (k) => (k || '').replace(/^de_/, '').replace(/^\w/, (c) => c.toUpperCase());
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function extractTeams(doc) {
    const head = doc.querySelector('.map-stats-infobox-header');
    if (head) {
      const a = head.querySelector('.team:not(.team2)');
      const b = head.querySelector('.team.team2, .team2');
      const n1 = txt(a && a.querySelector('.team-name')) || txt(a);
      const n2 = txt(b && b.querySelector('.team-name')) || txt(b);
      if (n1 && n2) return { t1: n1, t2: n2 };
    }
    // На BO1-страницах инфобокса нет, берём команды из шапки матча, а не со
    // всей страницы — там 70+ ссылок на команды соседних матчей.
    const inBox = (scope) => {
      const names = [];
      for (const a of [...scope.querySelectorAll('a[href^="/team/"]')]) {
        const n = (a.textContent || '').trim().replace(/\s+/g, ' ');
        if (n && !names.includes(n)) names.push(n);
        if (names.length === 2) break;
      }
      return names;
    };
    const box = doc.querySelector('.teamsBox');
    let names = box ? inBox(box) : [];
    if (names.length < 2) names = inBox(doc);
    if (names.length === 2) return { t1: names[0], t2: names[1] };
    const title = /(.+?)\s+vs\.?\s+(.+?)(?:\s+at\s|$)/.exec(doc.title || '');
    if (title) return { t1: title[1].trim(), t2: title[2].trim() };
    return null;
  }

  // Реальное вето: "1. Butterfly removes Nuke" / "7. Inferno was left over".
  // Симуляция HLTV та же по форме, но в настоящем времени и с процентом на
  // конце: "1. Underworld removes Nuke 70%" / "7. Ancient is left over 47%".
  function parseVetoLine(line) {
    let m = /^(?:\d+\.\s*)?(.+?)\s+(removed|removes|banned|bans|picked|picks|chosen)\s+(.+?)\s*(?:\d+\s*%)?\.?$/i.exec(line);
    if (m) {
      return { team: m[1].trim(), act: /ban|remov/i.test(m[2]) ? 'ban' : 'pick',
               mapName: m[3].trim() };
    }
    m = /^(?:\d+\.\s*)?(.+?)\s+(?:was|is|will be)\s+left\s+over\s*(?:\d+\s*%)?\.?$/i.exec(line);
    if (m) return { team: null, act: 'leftover', mapName: m[1].trim() };
    return null;
  }

  // Настоящее вето живёт в .veto-box, но симуляция HLTV сидит в блоке с теми же
  // классами (.veto-box.simulated-veto): без фильтра несыгранное вето
  // читается как сыгранное.
  function extractVeto(doc) {
    const host = doc.querySelector('.veto-box:not(.simulated-veto)');
    if (!host) return [];
    const steps = [];
    for (const node of [...host.querySelectorAll('.padding div')]) {
      const s = parseVetoLine(txt(node));
      if (s) {
        s.map = mapKey(s.mapName);
        steps.push(s);
      }
    }
    return steps;
  }

  // Формат: "Best of 3 (Online)" лежит в подписи блока вето; если его там нет,
  // берём первый "Best of N" из текста страницы.
  function extractFormat(doc) {
    const host = doc.querySelector('.veto-box:not(.simulated-veto)');
    const texts = [host && host.innerText, doc.body && doc.body.innerText].filter(Boolean);
    for (const text of texts) {
      const m = /Best of (\d)/i.exec(text);
      if (m) return parseInt(m[1], 10);
    }
    return null;
  }

  // Окно статистики, по которой HLTV считает винрейты, зашито в href ссылок
  // инфобокса: startDate=2026-08-05&endDate=2026-11-05
  function extractWindow(doc) {
    const a = doc.querySelector('.map-stats-infobox-winpercentage a');
    const href = a ? a.getAttribute('href') || '' : '';
    const s = /[?&]startDate=(\d{4})-(\d{2})-(\d{2})/.exec(href);
    const e = /[?&]endDate=(\d{4})-(\d{2})-(\d{2})/.exec(href);
    return s && e ? `${s[3]}.${s[2]} — ${e[3]}.${e[2]}` : null;
  }

  function extractMapStats(doc) {
    const cell = (el) => {
      if (!el) return null;
      const playedText = txt(el.querySelector('.map-stats-infobox-maps-played'));
      return {
        wr: pctVal(txt(el.querySelector('.map-stats-infobox-winpercentage'))),
        games: intVal(playedText),
        isMapCount: /map/i.test(playedText),
        mark: el.querySelector('.map-stats-infobox-pick') ? 'pick'
          : el.querySelector('.map-stats-infobox-ban') ? 'ban' : null,
        adv: !!el.querySelector('.map-stats-infobox-winpercentage.advantage'),
      };
    };
    // В DOM висят три секции инфобокса (Win/Pick/Ban): в винрейтах HLTV пишет
    // «N maps», в пик/бан-статистике — «N possibilities».
    return [...doc.querySelectorAll('.map-stats-infobox-maps')].map((box) => {
      const code = box.getAttribute('data-mapname') || '';
      const name = txt(box.querySelector('.mapname')) || code;
      const key = mapKey(code) || mapKey(name);
      const t1 = box.querySelector('.map-stats-infobox-stats:not(.team2)');
      const t2 = box.querySelector('.map-stats-infobox-stats.team2');
      return {
        map: key, mapName: mapLabel(key) || name,
        t1: cell(t1), t2: cell(t2),
        notPicked: /not-picked/.test(box.className),
      };
    }).filter((r) => r.mapName
      && ((r.t1 && r.t1.isMapCount) || (r.t2 && r.t2.isMapCount) || !r.t1 && !r.t2));
  }

  // Симуляция вето HLTV: вкладки Likeliest / 2nd / 3rd — берём первую.
  function extractSimulated(doc) {
    const alt = doc.querySelector('.simulated-veto-alt--0') || doc.querySelector('.simulated-veto-alt');
    if (!alt) return null;
    const steps = [...alt.querySelectorAll('.simulated-veto-step')].map((n) => {
      const chanceEl = n.querySelector('.simulated-veto-step-chance');
      // textContent шага склеивает название карты и процент («Dust2» + «49%» =
      // «Dust249%»), поэтому процент берём из отдельного span, а текст — без него.
      const raw = [...n.childNodes].filter((c) => c !== chanceEl)
        .map((c) => c.textContent).join('').replace(/\s+/g, ' ').trim();
      const s = parseVetoLine(raw);
      if (!s) return null;
      s.chance = intVal(txt(chanceEl));
      s.map = mapKey(s.mapName);
      return s;
    }).filter(Boolean);
    if (!steps.length) return null;
    return {
      steps,
      line: txt(alt.querySelector('.simulated-veto-maps-line')).replace(/\s+/g, ' '),
      maps: steps.filter((s) => s.act !== 'ban').map((s) => s.mapName),
    };
  }

  function extractProMatch(doc) {
    const veto = extractVeto(doc);
    let bo = extractFormat(doc);
    if (!bo) {
      // Если подписи «Best of N» на странице нет, формат выводим из протокола
      // вето: сколько карт осталось после банов (BO1 = 1, BO3 = 3, BO5 = 5).
      const left = veto.filter((s) => s.act !== 'ban').length;
      if (veto.length >= 3 && left >= 1 && left <= 5) bo = left;
    }
    return {
      teams: extractTeams(doc),
      veto,
      maps: extractMapStats(doc),
      sim: extractSimulated(doc),
      bo,
      win: extractWindow(doc),
      noVeto: !!doc.querySelector('.map-stats-infobox-right.no-veto'),
    };
  }

  window.__hltvExtractProMatch = extractProMatch;

  // ---------- вывод ----------

  function analyse(m) {
    const vetoRole = {};
    for (const s of (m.veto || [])) {
      const k = s.map || s.mapName;
      if (k) vetoRole[k] = { act: s.act, team: s.team };
    }
    const rows = (m.maps || []).map((r) => {
      const g1 = r.t1 && r.t1.games != null ? r.t1.games : 0;
      const g2 = r.t2 && r.t2.games != null ? r.t2.games : 0;
      const ok = !!(r.t1 && r.t2) && r.t1.wr != null && r.t2.wr != null
        && g1 >= MIN_GAMES && g2 >= MIN_GAMES;
      const v = vetoRole[r.map] || vetoRole[r.mapName];
      const inSeries = v ? v.act === 'pick' || v.act === 'leftover'
        : !r.notPicked && !!(r.t1 && r.t1.mark === 'pick' || r.t2 && r.t2.mark === 'pick');
      return {
        map: r.map, mapName: r.mapName, t1: r.t1, t2: r.t2, ok, inSeries,
        role: v ? (v.act === 'leftover' ? 'осталась'
          : `${v.act === 'ban' ? 'бан' : 'пик'} ${v.team || ''}`.trim())
          : r.notPicked ? 'вне серии' : '',
        games: Math.min(g1, g2),
        diff: ok ? r.t1.wr - r.t2.wr : null,
      };
    });
    const sum = (side) => rows.reduce((s, r) => s + (r[side] && r[side].games || 0), 0);
    const rated = rows.filter((r) => r.ok);
    const byAbs = (a, b) => Math.abs(a.diff) - Math.abs(b.diff);

    // О чём говорит вердикт: сначала реальное вето, затем симуляция HLTV,
    // затем весь пул.
    const series = rated.filter((r) => r.inSeries);
    const simNames = (m.sim && m.sim.maps) || [];
    const likely = simNames.length
      ? rated.filter((r) => simNames.some((n) => (mapKey(n) || n) === (r.map || r.mapName)))
      : [];
    const set = series.length ? series : (likely.length ? likely : rated);
    const seriesAll = rows.filter((r) => r.inSeries).length;
    const label = series.length ? 'картам серии'
      : likely.length ? 'вероятным картам из симуляции HLTV' : 'всему пулу';
    const sorted = set.slice().sort(byAbs);
    return {
      rows, rated, set, label, decided: series.length > 0, seriesAll,
      lead: sorted.length ? sorted[sorted.length - 1] : null,
      ahead1: set.filter((r) => r.diff > 0).length,
      ahead2: set.filter((r) => r.diff < 0).length,
      poolGames: { t1: sum('t1'), t2: sum('t2') },
    };
  }

  function cellWr(c) {
    if (!c) return '<span class="hp-dim">—</span>';
    if (c.wr == null) {
      return c.games === 0 ? '<span class="hp-dim">нет игр</span>'
        : `<span class="hp-dim">—${c.games ? ` (${c.games})` : ''}</span>`;
    }
    const g = c.games == null ? '' : ` <span class="hp-games">(${c.games})</span>`;
    return `${Math.round(c.wr)}%${g}${c.mark ? ` <span class="hp-mark hp-${c.mark}">${c.mark === 'pick' ? 'Пик' : 'Бан'}</span>` : ''}`;
  }

  function render(m, host) {
    const a = analyse(m);
    const t1 = m.teams ? m.teams.t1 : 'К1';
    const t2 = m.teams ? m.teams.t2 : 'К2';

    const head = `<div class="hp-head"><span>PRO · ВЕТО И КАРТЫ</span>`
      + `<span class="hp-bo">${m.bo ? `BO${m.bo}` : 'BO?'} · винрейты HLTV${m.win ? `, окно ${m.win}` : ''}</span></div>`;

    const vetoLine = (m.veto && m.veto.length)
      ? `<div class="hp-veto">${m.veto.map((s) => (s.act === 'leftover'
          ? `<b>${esc(mapLabel(s.map) || s.mapName)}</b> — осталась`
          : `${s.act === 'ban' ? 'бан' : 'пик'}: <b>${esc(mapLabel(s.map) || s.mapName)}</b> (${esc(s.team)})`
        )).join(' · ')}</div>`
      : (m.sim
          ? `<div class="hp-veto hp-dim">Вето ещё не сыграно. Симуляция HLTV: `
            + m.sim.steps.map((s) => `${s.act === 'ban' ? 'бан' : s.act === 'leftover' ? 'остаток' : 'пик'} `
              + `<b>${esc(s.mapName)}</b> ${s.chance == null ? '' : s.chance + '%'}`).join(', ')
            + (m.sim.line ? `. ${esc(m.sim.line)}` : '') + `</div>`
          : '');

    const pp = (d) => `${Math.abs(d).toFixed(0)} п.п.`;
    const ofWho = (d) => (d > 0 ? t1 : t2);
    const against = (d) => (d > 0 ? t2 : t1);
    const gapOf = (r) => `${Math.round(r.diff > 0 ? r.t1.wr : r.t2.wr)}% против `
      + `${Math.round(r.diff > 0 ? r.t2.wr : r.t1.wr)}%`;

    if (!m.maps.length) {
      host.innerHTML = head + vetoLine
        + `<div class="hp-rec hp-low">HLTV не выложил статистику карт для этого матча `
        + `(так бывает в BO1) — сравнивать винрейты ни по чем, ниже только разбор вето.</div>`
        + `<div class="hp-note">Это разбор статистики, а не прогноз модели. Не связано с HLTV.</div>`;
      return;
    }

    let verdict;
    if (!a.lead) {
      const weak = a.poolGames.t1 <= a.poolGames.t2 ? [t1, a.poolGames.t1] : [t2, a.poolGames.t2];
      verdict = `<div class="hp-rec hp-low">Сравнивать нечего: у <b>${esc(weak[0])}</b> `
        + `${weak[1]} сыгранных карт на всём пуле${m.win ? ` в окне HLTV ${m.win}` : ''}. `
        + `HLTV считает винрейты только по составу, отыгравшему вместе минимум 3 матча, `
        + `поэтому чисел для сравнения нет.`
        + (m.sim ? ' Выше — симуляция вето, сейчас это единственный ориентир.' : '') + `</div>`;
    } else {
      const b = a.lead;
      const n = a.set.length;
      const draw = a.ahead1 === a.ahead2;
      const leader = a.ahead1 > a.ahead2 ? t1 : t2;
      const noise = Math.abs(b.diff) < NOISE_PP;
      const thin = b.games < THIN_GAMES;
      verdict = `<div class="hp-rec${noise || thin ? ' hp-low' : ''}">`
        + (draw
          ? `По ${a.label} равновесие (${a.ahead1}:${a.ahead2}).`
          : `По ${a.label} перевес у <b>${esc(leader)}</b> — сильнее на ${Math.max(a.ahead1, a.ahead2)} из ${n} карт.`)
        + ` Крупнейший разрыв — <b>${esc(b.mapName)}</b>: у <b>${esc(ofWho(b.diff))}</b> ${pp(b.diff)} (${gapOf(b)}),`
        + ` у <b>${esc(against(b.diff))}</b> — наоборот.`
        + (noise ? ` Разрыв меньше ${NOISE_PP} п.п. — это шум, а не сигнал.` : '')
        + (thin && !noise ? ` Выборка тонкая: ${b.games} сыгранных карт у слабой стороны.` : '')
        + (a.seriesAll > a.set.length
            ? ' Часть карт серии в вердикт не вошла: у HLTV нет по ним сопоставимой выборки.'
            : '')
        + (a.decided ? '' : ' Карты серии ещё не утверждены — после вето картина изменится.')
        + `</div>`;
    }

    const body = a.rows.map((r) => {
      const cls = [r.ok ? '' : 'hp-dim', r === a.lead ? 'hp-good' : ''].filter(Boolean).join(' ');
      const d = r.diff == null ? '—' : `${r.diff > 0 ? '+' : ''}${r.diff.toFixed(0)}`;
      const dcls = r.diff == null ? 'hp-dim' : r.diff > 0 ? 'hp-g' : r.diff < 0 ? 'hp-r' : '';
      return `<tr class="${cls}"><td class="hp-map">${esc(r.mapName)}`
        + `<span class="hp-role">${esc(r.role)}</span></td>`
        + `<td>${cellWr(r.t1)}</td><td>${cellWr(r.t2)}</td>`
        + `<td class="${dcls}">${d}</td></tr>`;
    }).join('');

    host.innerHTML = head + vetoLine + verdict
      + `<table class="hp-table"><thead><tr><th>Карта</th><th>${esc(t1)}</th><th>${esc(t2)}</th><th>Δ п.п.</th></tr></thead>`
      + `<tbody>${body}</tbody></table>`
      + `<div class="hp-note">Δ = разница винрейтов (${esc(t1)} минус ${esc(t2)}); в скобках — число карт в выборке. `
      + `«Вне серии» — карты, не вошедшие в BO. Это разбор статистики, а не прогноз модели. Не связано с HLTV.</div>`;
  }

  function mount() {
    const onMatch = /^\/matches\/\d+/.test(location.pathname) || window.__hltvForceMount;
    if (!onMatch) return;
    const m = extractProMatch(document);
    if (!m.maps.length && !m.veto.length) return;

    let host = document.getElementById('hltv-pro-panel');
    if (!host) {
      host = document.createElement('div');
      host.id = 'hltv-pro-panel';
      host.className = 'hltv-pro';
      const anchor = document.querySelector('.map-stats-infobox')
        || document.querySelector('.veto-box:not(.simulated-veto)')
        || document.querySelector('#main') || document.body;
      if (anchor === document.body) anchor.appendChild(host);
      else anchor.parentNode.insertBefore(host, anchor);
    }
    render(m, host);
  }

  mount();
  // инфоблок и симуляция вето домонтируются после загрузки страницы
  let tries = 0;
  const timer = setInterval(() => {
    mount();
    if (++tries > 12) clearInterval(timer);
  }, 1000);
})();
